

export const Header = () => {
  return (
    <header className="header"><span className="headerSpan">Este es el header</span></header>
  )
}




export const Footer = () => {
  return (
    <footer><span className="footerSpan">Este es el footer</span></footer>
  )
}

